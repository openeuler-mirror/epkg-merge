import os
import time
start = time.time()
cli = r"merge-configs -c /Users/duan/workspace/gitee/merge-package-configs/tests/demo/config.yaml -p "
demo_path = r"/Users/duan/workspace/gitee/merge-package-configs/tests/demo/layer_os/pkgs"
a = []
for spec_name in os.listdir(demo_path):
    # p = spec_name
    if spec_name in [".DS_Store",".keep","index.yaml"]:
        continue
    a.append(spec_name)

cli = cli + '"'+" ".join(a)+'"'
import sys

os.system(cli)
print(time.time() - start)